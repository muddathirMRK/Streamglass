# StreamGlass v0.1

Working-first iOS 26 SwiftUI prototype: WKWebView browser, popup-window blocking, accessible DOM media detection, AVPlayer playback, Fit/Fill/Zoom/Custom framing, pinch/drag custom framing, WebKit AirPlay/PiP configuration, and Liquid Glass controls.

This is a foundation build. It intentionally does not bypass DRM, authentication, paywalls, anti-access systems, or harvest unauthorized streams.
